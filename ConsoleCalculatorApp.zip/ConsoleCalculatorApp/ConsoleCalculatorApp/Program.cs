﻿//Declare variables and then initialize to zero.
using System;

int num1 = 0; int num2 = 0;

// Display title of C# console app
Console.WriteLine("ConsoleCalculatorApp in C#\r");//the (backslash r) escape character is used
Console.WriteLine("-----------------------------------------------\n");//the (backslash n) escape character is used for new line

// Ask the user to type the first number or gather input
Console.WriteLine("Type a number that will update the 'num1' variable and press Enter");
num1 = Convert.ToInt32(Console.ReadLine());

// Ask the user to type the second number
Console.WriteLine("Type a number that will update the 'num2' variable and press Enter");
num2 = Convert.ToInt32(Console.ReadLine());
switch(num2)
{
    case 0: Console.WriteLine("press Enter") ;
        break;
}

// Ask the user to choose an operation for the numbers these lines below of code has no function
Console.WriteLine("Choose an option from the following list:");
Console.WriteLine("\ta - Add");
Console.WriteLine("\ts - Subtract");
Console.WriteLine("\tm - Multiply");
Console.WriteLine("\td - Divide");
Console.WriteLine("\tsqrt - square root");
Console.WriteLine("\tcbrt - cube root");
Console.Write("Your option? ");

//below is a C# switch statement that switches based on above code the switch
switch (Console.ReadLine())
{
    case "a":
        Console.WriteLine($"your result: {num1} + {num2} = " + (num1 + num2));
        break;

    case "s":
        Console.WriteLine($"Your result: {num1} - {num2} = " + (num1 - num2));
        break;

    case "m":
        Console.WriteLine($"Your result: {num1} * {num2} = " + (num1 * num2));
        break;

    case "d":
        Console.WriteLine($"Your result: {num1} / {num2} = " + (num1 / num2));
        break;

    case "sqrt":
        Console.WriteLine($"Your result: {num1} square root = {Math.Sqrt(num1)}");
        break;

    case "cbrt":
        Console.WriteLine($"Your result: {num1} square root = {Math.Cbrt(num1)}");
        break;
}
// Wait for the user to respond before before closing
Console.Write("Press any key to close the Calculator console app...");
Console.ReadKey();
// if worked correctly exit code should be int 0